package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * 文章标签关联表
 * @TableName article_tag_relation
 */
@TableName(value ="article_tag_relation")
@Data
public class ArticleTagRelation {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 文章 ID
     */
    private Long articleId;

    /**
     * 标签 ID
     */
    private Long tagId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0-否 1-是）
     */
    @TableLogic
    @JsonIgnore
    private Integer isDeleted;
}