package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import lombok.Data;

/**
 * 答题记录表
 * @TableName answer_record
 */
@TableName(value ="answer_record")
@Data
public class AnswerRecord {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 用户 ID
     */
    private Long userId;

    /**
     * 题目 ID
     */
    private Long questionId;

    /**
     * 用户答案（A/B/C/D）
     */
    private String userAnswer;

    /**
     * 是否正确（0-错误 1-正确）
     */
    private Integer isCorrect;

    /**
     * 获得积分
     */
    private Integer scoreEarned;

    /**
     * 答题时间
     */
    private Date answerTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 是否删除
     */
    private Integer isDeleted;
}