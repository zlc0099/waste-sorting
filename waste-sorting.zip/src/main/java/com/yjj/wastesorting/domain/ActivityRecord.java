package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * 活动参与记录表
 * @TableName activity_record
 */
@TableName(value ="activity_record")
@Data
public class ActivityRecord {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 活动 ID
     */
    private Long activityId;

    /**
     * 用户 ID
     */
    private Long userId;

    /**
     * 用户名
     */
    private String username;

    /**
     * 状态（0-已报名 1-已签到 2-已完成 3-已取消）
     */
    private Integer status;

    /**
     * 签到时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date checkInTime;

    /**
     * 获得积分
     */
    private Integer rewardPoints;

    /**
     * 创建时间
     */
    @JsonIgnore
    private Date createTime;

    /**
     * 是否删除
     */
    @JsonIgnore
    @TableLogic
    private Integer isDeleted;
}