package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * 奖品表
 * @TableName prize
 */
@TableName(value ="prize")
@Data
public class Prize {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 奖品名称
     */
    private String name;

    /**
     * 奖品图片 URL
     */
    private String imageUrl;

    /**
     * 奖品类型（1-实物 2-虚拟 3-优惠券）
     */
    private Integer type;

    /**
     * 所需积分
     */
    private Integer pointsRequired;

    /**
     * 库存数量
     */
    private Integer stock;

    /**
     * 总库存（用于统计）
     */
    private Integer totalStock;

    /**
     * 状态（0-下架 1-上架）
     */
    private Integer status;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonIgnore
    private Date createTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonIgnore
    private Date updateTime;

    /**
     * 是否删除（0-否 1-是）
     */
    @TableLogic
    @JsonIgnore
    private Integer isDeleted;
}