package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * 科普文章表
 * @TableName knowledge_article
 */
@TableName(value ="knowledge_article")
@Data
public class KnowledgeArticle {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 文章标题
     */
    private String title;

    /**
     * 文章内容
     */
    private String content;

    /**
     * 封面图片 URL
     */
    private String coverImage;


    /**
     * 作者名称
     */
    private String authorName;

    /**
     * 浏览次数
     */

    private Integer viewCount;

    /**
     * 点赞次数
     */

    private Integer likeCount;

    /**
     * 状态（0-草稿 1-发布）
     */
    private Integer status;

    /**
     * 发布时间
     */

    private Date publishTime;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;

    @JsonIgnore
    @TableLogic
    /**
     * 是否删除（0-否 1-是）
     */
    private Integer isDeleted;
}