package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * 环保活动表
 * @TableName environmental_activity
 */
@TableName(value ="environmental_activity")
@Data
public class EnvironmentalActivity {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 活动主题
     */
    private String title;

    /**
     * 活动描述
     */
    private String description;

    /**
     * 封面图片 URL
     */
    private String coverImage;

    /**
     * 主办方
     */
    private String organizer;

    /**
     * 联系电话
     */
    private String contactPhone;

    /**
     * 活动地点
     */
    private String location;

    /**
     * 最大参与人数
     */
    private Integer maxParticipants;

    /**
     * 当前报名人数
     */
    private Integer currentParticipants;

    /**
     * 参与奖励积分
     */
    private Integer rewardPoints;
    /*
     * 状态（0-报名中 1-已满员 2-进行中 3-已结束 4-已取消）
     */
    private Integer status;

    /**
     * 创建时间
     */
    @JsonIgnore
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonIgnore
    private Date updateTime;

    /**
     * 是否删除
     */
    @JsonIgnore
    @TableLogic
    private Integer isDeleted;
}