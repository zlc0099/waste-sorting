package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import lombok.Data;

/**
 * 文章点赞表
 * @TableName article_like
 */
@TableName(value ="article_like")
@Data
public class ArticleLike {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 文章 ID
     */
    private Long articleId;

    /**
     * 用户 ID
     */
    private Long userId;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0-否 1-是）
     */
    @TableLogic
    private Integer isDeleted;
}