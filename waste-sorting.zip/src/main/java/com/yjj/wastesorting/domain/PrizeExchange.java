package com.yjj.wastesorting.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * 奖品兑换记录表
 * @TableName prize_exchange
 */
@TableName(value ="prize_exchange")
@Data
public class PrizeExchange {
    /**
     * 主键 ID
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 奖品 ID
     */
    private Long prizeId;

    /**
     * 用户 ID
     */
    private Long userId;

    /**
     * 用户名（冗余字段）
     */
    private String username;

    /**
     * 使用积分
     */
    private Integer pointsUsed;

    /**
     * 兑换状态（0-待兑换 1-已兑换）
     */
    private Integer status;

    /**
     * 备注
     */
    private String remark;

    /**
     * 兑换时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否删除（0-否 1-是）
     */
    @JsonIgnore
    @TableLogic
    private Integer isDeleted;
}