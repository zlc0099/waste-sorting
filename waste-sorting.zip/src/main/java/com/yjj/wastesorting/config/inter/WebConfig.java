package com.yjj.wastesorting.config.inter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Autowired
    private UserLoginInterceptor userLoginInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(userLoginInterceptor)  // ✅ 使用注入的 Bean
                .addPathPatterns("/**")  // ✅ 拦截所有路径
                .excludePathPatterns(     // ✅ 排除不需要登录的路径
                        "/user/login/login",
                        "/user/login/register",
                        "/admin/login",
                        "/swagger-resources/**",
                        "/webjars/**",
                        "/v3/**",
                        "/doc/**"
                );
    }
}