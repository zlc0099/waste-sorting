package com.yjj.wastesorting.config.inter;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
@Component
public class UserLoginInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 从请求头获取用户 ID（或者从 Cookie/Session）
        String userIdStr = request.getHeader("X-User-Id");
        String username = request.getHeader("X-Username");

        if (userIdStr != null && !userIdStr.isEmpty()) {
            try {
                Long userId = Long.parseLong(userIdStr);
                // 将登录用户信息保存到 ThreadLocal
                LoginUserHolder.setLoginUser(new LoginUser(userId, username));
            } catch (NumberFormatException e) {
                // 忽略格式错误
            }
        }

        return true; // 继续执行
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // 请求完成后清理 ThreadLocal，防止内存泄漏
        LoginUserHolder.clear();
    }
}