package com.yjj.wastesorting.controller.Question;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserAnswerStatVo;
import com.yjj.wastesorting.domain.AnswerRecord;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.AnswerRecordService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户回答问题记录管理")
@RestController
@RequestMapping("/admin/answerRecord/")
public class QuestionUserController {
    @Autowired
    private AnswerRecordService answerRecordService;
    @Operation(summary = "根据id删除记录")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id) {
        answerRecordService.removeById(id);
        return Result.ok();
    }
    @Operation(summary = "分页查询记录")
    @GetMapping("pageQuery")
    public Result<IPage<UserAnswerStatVo>> pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        Page<UserAnswerStatVo> page = new Page<>(pageNum, pageSize);
        IPage<UserAnswerStatVo> pageModel = answerRecordService.userStatPageQuery(page);
        return Result.ok(pageModel);
    }
}
