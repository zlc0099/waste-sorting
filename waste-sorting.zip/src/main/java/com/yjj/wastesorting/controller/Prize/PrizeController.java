package com.yjj.wastesorting.controller.Prize;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.PrizeVo;
import com.yjj.wastesorting.Vo.UserListVo;
import com.yjj.wastesorting.domain.Prize;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.PrizeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "奖品管理")
@RestController
@RequestMapping("/admin/prize/")
public class PrizeController{
    @Autowired
    private PrizeService prizeService;
    @Operation(summary = "保存或更新奖品")
    @PostMapping("saveOrUpdate")
    public Result saveOrUpdate(@RequestBody PrizeVo prizeVo) {
        prizeService.PrizeSaveOrUpdate(prizeVo);
        return Result.ok();
    }
    @Operation(summary = "根据id删除奖品")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id) {
        prizeService.removeById(id);
        return Result.ok();
    }
    @Operation(summary = "根据Id查询奖品")
    @GetMapping("get")
    public Result<Prize> get(@RequestParam Long id) {
        Prize prize = prizeService.getById(id);
        return Result.ok(prize);
    }
    @Operation(summary = "根据id设置奖品上架状态")
    @PostMapping("setStatus")
    public Result setStatus(@RequestParam Long id, @RequestParam Integer status) {
        LambdaUpdateWrapper<Prize> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(Prize::getId, id)
                .set(Prize::getStatus, status);
                prizeService.update(updateWrapper);
        return Result.ok();
    }
    @Operation(summary = "分页查询奖品")
    @GetMapping("pageQuery")
    public Result<IPage<Prize>> pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize, @RequestParam(required = false) String prizeName) {
        Page<Prize> page = new Page<>(pageNum, pageSize);
        IPage<Prize> pageModel = prizeService.pageQuery(page, prizeName);
        return Result.ok(pageModel);
    }

}
