package com.yjj.wastesorting.controller.User;

import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.UserCheckInService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@Tag(name = "用户签到")
@RestController
@RequestMapping("/user/checkIn")
public class UserCheckInController{
    @Autowired
    private UserCheckInService userCheckInService;
    @Operation(description = "用户签到")
    @PostMapping("/checkIn")
    public Result checkIn()
    {
        userCheckInService.checkIn();
        return Result.ok();
    }
}
