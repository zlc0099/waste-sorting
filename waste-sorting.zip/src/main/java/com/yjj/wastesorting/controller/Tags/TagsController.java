package com.yjj.wastesorting.controller.Tags;

import com.yjj.wastesorting.domain.Tags;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.TagService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "标签管理")
@RestController
@RequestMapping("/admin/tags/")
public class TagsController {

    @Autowired
    private TagService tagService;
    @Operation(description = "查询标签列表")
    @GetMapping("/list")
    public Result<List<Tags>> list(){
        List<Tags> list = tagService.list();
        return Result.ok(list);
    }
    @Operation(description = "添加标签")
    @PostMapping("/add")
    public Result add(@RequestParam String tagName){
        tagService.add(tagName);
        return Result.ok();
    }
    @Operation(description = "删除标签")
    @DeleteMapping("/delete")
    public Result delete(@RequestParam Long id){
        tagService.removeById(id);
        return Result.ok();
    }

}
