package com.yjj.wastesorting.controller.User;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserVo;
import com.yjj.wastesorting.domain.User;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户管理")
@RestController
@RequestMapping("/admin/user/")
public class UserController {
    @Autowired
    private UserService userService;
    @Operation(description = "添加或修改用户")
    @PostMapping("saveOrupdate")
    public Result<User> saveOrupdate(@RequestBody UserVo userVo)
    {
        userService.saveOrupdate(userVo);
        return Result.ok();
    }
    @Operation(description = "删除用户")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id)
    {
        userService.removeById(id);
        return Result.ok();
    }
    @Operation(description = "设置用户状态")
    @PostMapping("setStatus")
    public Result setStatus(@RequestParam Long id,@RequestParam Integer status)
    {
        userService.updateStatus(id,status);
        return Result.ok();
    }
    @Operation(description = "分页查询用户")
    @GetMapping("pageuser")
    public Result<IPage<User>> userPage(@RequestParam Integer pageNum, @RequestParam Integer pageSize, @RequestParam(required = false) String username)
    {
        Page<User> page = new Page<>(pageNum,pageSize);
        IPage<User> pageModel = userService.pageQuery(page,username);
        return Result.ok(pageModel);
    }
    @Operation(description = "根据id查询用户")
    @GetMapping("getById")
    public Result<User> getById(@RequestParam Long id)
        {
        User user = userService.getById(id);
        return Result.ok(user);
    }
}
