package com.yjj.wastesorting.controller.Question;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.AnswerQuestionVo;
import com.yjj.wastesorting.Vo.AnswerResultVo;
import com.yjj.wastesorting.domain.AnswerRecord;
import com.yjj.wastesorting.domain.Question;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.AnswerRecordService;
import com.yjj.wastesorting.service.QuestionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户回答问题记录管理")
@RestController
@RequestMapping("/user/answerRecord/")
public class AnswerRecordController {

    @Autowired
    private AnswerRecordService answerRecordService;

    @Autowired
    private QuestionService questionService;

    @Operation(summary = "获取随机题目（受每日限制）")
    @GetMapping("/random")
    public Result<Page<Question>> getRandomQuestions(@RequestParam(defaultValue = "5") Integer count) {
        Page<Question> questions = questionService.getRandomQuestions(count);
        return Result.ok(questions);
    }

    @Operation(summary = "回答问题（带每日限制检查）")
    @PostMapping("/answer")
    public Result<AnswerResultVo> answerQuestion(@RequestBody AnswerQuestionVo answerQuestionVo) {
        Result<Integer> checkResult = answerRecordService.checkTodayAnswerLimit();

        if (checkResult.getCode() != 200) {
            throw new RuntimeException("今日答题次数已用完，明天再来吧！");
        }

        int remainingCount = checkResult.getData();
        if (remainingCount <= 0) {
            throw new RuntimeException("今日答题次数已用完，明天再来吧！");
        }

        Result<AnswerResultVo> result = questionService.answerQuestion(answerQuestionVo);

        if (result.getCode() == 200 && result.getData() != null) {
            result.setMessage("答题成功，今日还可答题 " + (remainingCount - 1) + " 次");
        }

        return result;
    }

    @Operation(summary = "查询今日答题情况")
    @GetMapping("/todayStatus")
    public Result getTodayAnswerStatus() {
        Result<Integer> result = answerRecordService.checkTodayAnswerLimit();

        if (result.getCode() == 200) {
            Object statusData = new Object() {
                public Integer answeredCount = 5 - result.getData();
                public Integer remainingCount = result.getData();
                public Integer dailyLimit = 5;
            };
            return Result.ok(statusData);
        } else {
            return Result.fail();
        }
    }

    @Operation(summary = "分页查询答题记录")
    @GetMapping("/pageQuery")
    public Result pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        Page<AnswerRecord> page = answerRecordService.pageQuery(pageNum, pageSize);
        return Result.ok(page);
    }
}