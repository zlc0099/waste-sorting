package com.yjj.wastesorting.controller.Paper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserPaperListVo;
import com.yjj.wastesorting.Vo.UserReadVo;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.KnowledgeArticleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@Tag(name = "用户阅读文章管理")
@RestController
@RequestMapping("/user/paper/")
public class UserPaperController {
    @Autowired
    private KnowledgeArticleService userPaperService;
    @Operation(summary = "分页查询文章列表")
    @GetMapping("/pagepaper")
    public Result<IPage<UserPaperListVo>> pagePaper(@RequestParam Integer pageNum, @RequestParam Integer pageSize,String Keyword)
    {
        Page<UserPaperListVo> page = new Page<>(pageNum,pageSize);
        IPage<UserPaperListVo> pageModel = userPaperService.pagePaper(page,Keyword);
        return Result.ok(pageModel);
    }
    @Operation(summary = "根据id查询文章具体内容")
    @GetMapping("/papergetbyid")
    public Result<UserReadVo> paperGetById(@RequestParam Long id)
    {
        UserReadVo userReadV0 = userPaperService.readPaperGetById(id);
        return Result.ok(userReadV0);
    }
    @Operation(summary = "点赞文章")
    @GetMapping("/likepaper")
    public Result likePaper(@RequestParam Long id)
        {
            userPaperService.likePaper(id);
            return Result.ok();
        }
    @Operation(summary = "查看点赞文章记录")
    @GetMapping("/likepaperlist")
    public Result<IPage<UserPaperListVo>> likePaperList(@RequestParam Integer pageNum, @RequestParam Integer pageSize)
    {
        Page<UserPaperListVo> page = new Page<>(pageNum,pageSize);
        LoginUser loginUser = LoginUserHolder.getLoginUser();
        IPage<UserPaperListVo> pageModel = userPaperService.pageLikePaper(page,loginUser.getUserId());
        return Result.ok(pageModel);
    }
}
