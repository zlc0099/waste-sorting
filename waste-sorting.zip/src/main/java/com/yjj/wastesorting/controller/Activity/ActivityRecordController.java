package com.yjj.wastesorting.controller.Activity;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.ActivityRecordVo;
import com.yjj.wastesorting.domain.ActivityRecord;
import com.yjj.wastesorting.domain.User;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.ActivityRecordService;
import com.yjj.wastesorting.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;

@Tag(name = "活动记录管理")
@RestController
@RequestMapping("/admin/activityrecord/")
public class ActivityRecordController {
    @Autowired
    private ActivityRecordService activityRecordService;
    @Autowired
    private UserService userService;
    @Operation(summary = "根据Id删除活动记录")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id) {
        activityRecordService.removeById(id);
        return Result.ok();
    }
    @Operation(summary = "根据id修改参与用户参与活动状态")
    @PostMapping("update")
    public Result update(@RequestParam Long id) {
        LambdaUpdateWrapper<ActivityRecord> updateWrapper = new LambdaUpdateWrapper<>();
        LambdaQueryWrapper<ActivityRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRecord::getId, id);
        ActivityRecord activityRecord = activityRecordService.getOne(queryWrapper);
        if(activityRecord.getStatus()==1)
        {
            throw new RuntimeException("该用户已签到");
        }
        updateWrapper.eq(ActivityRecord::getId, id).set(ActivityRecord::getStatus, 1);
        activityRecordService.update(updateWrapper);
        User user = userService.getById(activityRecord.getUserId());
        user.setPoints(user.getPoints()+activityRecord.getRewardPoints());
        userService.updateById(user);
        return Result.ok();
    }
    @Operation(summary = "分页查询记录表")
    @GetMapping("pageQuery")
    public Result<IPage<ActivityRecordVo>> pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        Page<ActivityRecordVo> page = new Page<>(pageNum, pageSize);
        IPage<ActivityRecordVo> pageModel = activityRecordService.recondPage(page);
        return Result.ok(pageModel);
    }
}
