package com.yjj.wastesorting.controller.Activity;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserActivityKeyVo;
import com.yjj.wastesorting.Vo.UserActivityVo;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.ActivityRecordService;
import com.yjj.wastesorting.service.EnvironmentalActivityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户活动")
@RestController
@RequestMapping("/user/activity/")
public class UserActivityController {
    @Autowired
    private EnvironmentalActivityService environmentalActivityService;
    @Autowired
    private ActivityRecordService activityRecordService;
    @Operation(summary = "获取活动列表")
    @GetMapping("getActivity")
    public Result<IPage<UserActivityVo>> getActivity(@RequestParam Integer pageNum,@RequestParam Integer pageSize,String Keyword)
        {
        IPage<UserActivityVo> page = new Page<>(pageNum,pageSize);
        IPage<UserActivityVo> pageModel = environmentalActivityService.getActivity(page,Keyword);
        return Result.ok(pageModel);
    }
    @Operation(summary = "根据id获取活动详情")
    @GetMapping("getActivityById")
    public Result<UserActivityKeyVo> getActivityById(@RequestParam Long id)
    {
        UserActivityKeyVo userActivityKeyVo = environmentalActivityService.getKeyById(id);
        return Result.ok(userActivityKeyVo);
    }
    @Operation(summary = "用户根据id报名活动")
    @PostMapping("signUp")
    public Result signUp(@RequestParam Long id)
    {
        environmentalActivityService.saveJoinUser(id);
        return Result.ok();
    }
}
