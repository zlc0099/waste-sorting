package com.yjj.wastesorting.controller.Login;

import com.yjj.wastesorting.Vo.LoginVo;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.AdminService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@Tag(name = "登录管理")
@RestController
@RequestMapping("/admin/")
public class LoginController{
    @Autowired
    private AdminService adminService;
    @Operation(summary = "登录")
    @PostMapping("login")
    public Result login(@RequestBody LoginVo admin)
    {
        adminService.login(admin);
        return Result.ok();
    }
}
