package com.yjj.wastesorting.controller.Login;

import com.yjj.wastesorting.Vo.Register;
import com.yjj.wastesorting.Vo.UserInfoVo;
import com.yjj.wastesorting.Vo.UserLoginVo;
import com.yjj.wastesorting.Vo.UserVo;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name="前台用户登录")
@RestController
@RequestMapping("/user/login")
public class UserLoginController {
    @Autowired
    private UserService userService;
    @Operation(summary = "用户注册")
    @PostMapping("/register")
    public Result userRegister(@RequestBody Register register)
    {
        userService.userRegitst(register);
        return Result.ok();
    }
    @Operation(summary = "用户登录")
    @PostMapping("/login")
    public Result<UserVo> userLogin(@RequestBody UserLoginVo userLoginVo)
    {
        UserVo userVo = userService.userLogin(userLoginVo);
        if (userVo != null && userVo.getId() != null) {
            LoginUser loginUser = new LoginUser(userVo.getId(), userVo.getUsername());
            LoginUserHolder.setLoginUser(loginUser);
            System.out.println("=== ✅ 登录成功：用户 " + userVo.getUsername() + " 已保存到 LoginUserHolder ===");
        }
        System.out.println(LoginUserHolder.getLoginUser().getUserId());
        return Result.ok(userVo);
    }
    @Operation(summary = "获取当前用户信息")
    @GetMapping("info")
    public Result<UserInfoVo> getInfo()
    {
        System.out.println(LoginUserHolder.getLoginUser().getUserId());
        try {
            LoginUser loginUser = LoginUserHolder.getLoginUser();

            if (loginUser == null) {
                return Result.fail();
            }

            Long id = loginUser.getUserId();
            UserInfoVo userInfoVo = userService.getUserInfo(id);
            return Result.ok(userInfoVo);
        } catch (Exception e) {
            return Result.fail();
        }
    }
}

