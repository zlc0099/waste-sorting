package com.yjj.wastesorting.controller.Paper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.PaperReturnVo;
import com.yjj.wastesorting.Vo.PaperVo;
import com.yjj.wastesorting.Vo.pageVo;
import com.yjj.wastesorting.domain.KnowledgeArticle;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.KnowledgeArticleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "文章管理")
@RestController
@RequestMapping("/admin/paper/")
public class PaperController {
    @Autowired
    private KnowledgeArticleService knowledgeArticleService;
    @Operation(summary = "保存或更新文章")
    @PostMapping("saveOrupdate")
    public Result saveOrupdate(@RequestBody PaperVo paperVo) {
        knowledgeArticleService.saveOrupdate(paperVo);
        return Result.ok();
    }
    @Operation(summary = "删除文章")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id) {
        knowledgeArticleService.removeKonwledgeById(id);
        return Result.ok();
    }
    @Operation(summary = "根据ID查询文章")
    @GetMapping("getByid")
    public Result getByid(@RequestParam Long id) {
        PaperReturnVo knowledgeArticle = knowledgeArticleService.paperGetById(id);
        return Result.ok(knowledgeArticle);
    }
    @Operation(summary = "分页查询文章")
    @GetMapping("page")
    public Result<IPage<pageVo>> pagebyId(@RequestParam Integer pageNum, @RequestParam Integer pageSize, String search) {
        Page<pageVo> page = new Page<>(pageNum, pageSize);
        IPage<pageVo> pageModel = knowledgeArticleService.pageQuery(page, search);
        return Result.ok(pageModel);
    }
    @Operation(summary = "根据ID设置文章状态")
    @PostMapping("setStatus")
    public Result setStatus(@RequestParam Long id, @RequestParam Integer status) {
        LambdaQueryWrapper<KnowledgeArticle> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(KnowledgeArticle::getId, id);
        KnowledgeArticle knowledgeArticle = new KnowledgeArticle();
        knowledgeArticle.setStatus(status);
        knowledgeArticleService.update(knowledgeArticle, queryWrapper);
        return Result.ok();
    }

}
