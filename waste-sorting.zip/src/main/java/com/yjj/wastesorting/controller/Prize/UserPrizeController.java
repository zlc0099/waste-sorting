package com.yjj.wastesorting.controller.Prize;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserListVo;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.PrizeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name="用户兑换奖品")
@RestController
@RequestMapping("/user/Prize/")
public class UserPrizeController {
    @Autowired
    private PrizeService prizeService;
    @Operation(summary = "用户分页查询奖品列表")
    @GetMapping("pageQuery")
    public Result<IPage<UserListVo>> pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize, @RequestParam(required = false)Integer type) {
        Page<UserListVo> page = new Page<>(pageNum, pageSize);
        IPage<UserListVo> pageModel = prizeService.pagePrizeQuery(page, type);
        return Result.ok(pageModel);
    }
    @Operation(summary = "用户兑换奖品")
    @PostMapping("exchange")
    public Result exchange(@RequestParam Long id) {
        prizeService.exchange(id);
        return Result.ok();
    }

}
