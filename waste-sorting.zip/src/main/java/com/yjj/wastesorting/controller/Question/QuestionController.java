package com.yjj.wastesorting.controller.Question;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.questionVo;
import com.yjj.wastesorting.domain.Question;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.QuestionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "题目管理")
@RestController
@RequestMapping("/admin/question/")
public class QuestionController{
    @Autowired
    private QuestionService questionService;
    @Operation(summary = "添加或修改题目")
    @PostMapping("saveorupdate")
    public Result saveOrUpdate(@RequestBody questionVo questionVo){
        questionService.questionSaveOrUpdate(questionVo);
        return Result.ok();
    }
    @Operation(summary = "根据id删除题目")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id) {
        questionService.removeById(id);
        return Result.ok();
    }
    @Operation(summary = "根据id查询题目")
    @GetMapping("get")
    public Result<Question> get(@RequestParam Long id) {
        Question question = questionService.getById(id);
        return Result.ok(question);
    }
    @Operation(summary = "分页查询题目")
    @GetMapping("pageQuery")
    public Result<IPage<Question>> pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        Page<Question> page = new Page<>(pageNum, pageSize);
        IPage<Question> pageModel = questionService.page(page);
        return Result.ok(pageModel);
    }
    @Operation(summary = "根据id设置题目状态")
    @PostMapping("setStatus")
    public Result setStatus(@RequestParam Long id, @RequestParam Integer status) {
        LambdaUpdateWrapper<Question> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(Question::getId, id)
                .set(Question::getStatus, status);
                questionService.update(updateWrapper);
                return Result.ok();
    }
}
