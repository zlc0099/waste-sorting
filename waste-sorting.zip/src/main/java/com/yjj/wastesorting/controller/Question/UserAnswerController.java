package com.yjj.wastesorting.controller.Question;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.AnswerQuestionVo;
import com.yjj.wastesorting.Vo.AnswerResultVo;
import com.yjj.wastesorting.domain.Question;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.QuestionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户答题")
@RestController
@RequestMapping("/user/answer/")
public class UserAnswerController {
    
    @Autowired
    private QuestionService questionService;
    
    @Operation(summary = "获取随机题目")
    @GetMapping("/random")
    public Result<Page<Question>> getRandomQuestions(@RequestParam(defaultValue = "10") Integer count) {
        Page<Question> questions = questionService.getRandomQuestions(count);
        return Result.ok(questions);
    }
    
    @Operation(summary = "回答问题")
    @PostMapping("/answer")
    public Result<AnswerResultVo> answerQuestion(@RequestBody AnswerQuestionVo answerQuestionVo) {
        Result<AnswerResultVo> result = questionService.answerQuestion(answerQuestionVo);
        return result;
    }
    
    @Operation(summary = "批量提交答案")
    @PostMapping("/batchAnswer")
    public Result batchAnswer(@RequestBody AnswerQuestionVo[] answers) {
        try {
            for (AnswerQuestionVo answer : answers) {
                questionService.answerQuestion(answer);
            }
            return Result.ok("批量提交成功");
        } catch (Exception e) {
            return Result.fail();
        }
    }
}