package com.yjj.wastesorting.controller.Prize;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.PrizeExchangeVo;
import com.yjj.wastesorting.domain.Prize;
import com.yjj.wastesorting.domain.PrizeExchange;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.PrizeExchangeService;
import com.yjj.wastesorting.service.PrizeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

//TODO
@Tag(name = "奖品兑换订单管理")
@RestController
@RequestMapping("/admin/prizechange/")
public class PrizeExchangeController {
    @Autowired
    private PrizeExchangeService prizeService;
    @Operation(summary = "根据id删除订单")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id) {
        prizeService.removeById(id);
        return Result.ok();
    }
    @Operation(summary = "根据id修改订单状态")
    @PostMapping("setStatus")
    public Result setStatus(@RequestParam Long id, @RequestParam Integer status) {
        LambdaUpdateWrapper<PrizeExchange> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(PrizeExchange::getId, id)
                .set(PrizeExchange::getStatus, status);
                prizeService.update(updateWrapper);
        return Result.ok();
    }
    @Operation(summary = "分页查询订单")
    @GetMapping("pageQuery")
    public Result<IPage<PrizeExchangeVo>> pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize, @RequestParam(required = false) String userName) {
        Page<PrizeExchangeVo> page = new Page<>(pageNum, pageSize);
        IPage<PrizeExchangeVo> pageModel = prizeService.pageQuery(page, userName);
        return Result.ok(pageModel);
    }

}
