package com.yjj.wastesorting.controller.Activity;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.ActivityVo;
import com.yjj.wastesorting.domain.EnvironmentalActivity;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.EnvironmentalActivityService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "活动管理")
@RestController
@RequestMapping("/admin/activity/")
public class ActivityController {
    @Autowired
    private EnvironmentalActivityService activityService;
    @Operation(summary = "保存或更新活动")
    @PostMapping("saveOrUpdate")
    public Result saveOrUpdate(@RequestBody ActivityVo activityVo) {
        activityService.activitySaveOrUpdate(activityVo);
        return Result.ok();
    }
    @Operation(summary = "根据Id删除活动")
    @DeleteMapping("delete")
    public Result delete(@RequestParam Long id) {
        activityService.removeById(id);
        return Result.ok();
    }
    @Operation(summary = "分页查询活动")
    @GetMapping("pageQuery")
    public Result<IPage<EnvironmentalActivity>> pageQuery(@RequestParam Integer pageNum, @RequestParam Integer pageSize) {
        Page<EnvironmentalActivity> page = new Page<>(pageNum, pageSize);
        IPage<EnvironmentalActivity> pageModel = activityService.page(page);
        return Result.ok(pageModel);
    }
    @Operation(summary = "根据id设置活动状态")
    @PostMapping("setStatus")
    public Result setStatus(@RequestParam Long id, @RequestParam Integer status) {
        LambdaUpdateWrapper<EnvironmentalActivity> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(EnvironmentalActivity::getId, id).set(EnvironmentalActivity::getStatus, status);
        activityService.update(updateWrapper);
        return Result.ok();
    }
}
