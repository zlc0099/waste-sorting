package com.yjj.wastesorting.controller.SystemUser;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.AddSystemUserVo;
import com.yjj.wastesorting.domain.Admin;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.AdminService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统用户管理")
@RestController
@RequestMapping("/admin/system/")
public class SystemUserController{
    @Autowired
    private AdminService adminService;
    @Operation(description = "添加或修改系统用户")
    @PostMapping("saveOrUpdate")
    public Result SaveOrUpdate(@RequestBody AddSystemUserVo addSystemUserVo)
    {
        adminService.saveOrUpdate(addSystemUserVo);
        return Result.ok();
    }
    @Operation(description = "删除系统用户")
    @DeleteMapping("delete")
    public Result Delete(@RequestParam Long id)
    {
        adminService.removeById(id);
        return Result.ok();
    }
    @Operation(description = "分页查询系统用户")
    @GetMapping("page")
    public Result<IPage<Admin>> Page(@RequestParam Integer pageNum, @RequestParam Integer pageSize)
    {
        Page<Admin> page = new Page<>(pageNum,pageSize);
        IPage<Admin> pageModel = adminService.pageQuery(page);
        return Result.ok(pageModel);
    }
    @Operation(description = "根据ID查询系统用户")
    @GetMapping("getById")
    public Result<Admin> GetById(@RequestParam Long id)
        {
            Admin admin = adminService.getById(id);
            return Result.ok(admin);
        }
}
