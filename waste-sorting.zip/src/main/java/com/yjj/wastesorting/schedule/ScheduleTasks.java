package com.yjj.wastesorting.schedule;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.yjj.wastesorting.domain.UserCheckIn;
import com.yjj.wastesorting.service.UserCheckInService;
import com.yjj.wastesorting.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class ScheduleTasks {
    @Autowired
    private UserCheckInService userCheckInService;
    @Scheduled(cron = "0 0 0 * * *")
    public void updateLeaseStatus() {
        LambdaUpdateWrapper<UserCheckIn> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.in(UserCheckIn::getCheckIn,1);
        updateWrapper.set(UserCheckIn::getCheckIn,0);
        userCheckInService.update(updateWrapper);
    }
}
