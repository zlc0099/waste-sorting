package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.*;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.domain.ArticleLike;
import com.yjj.wastesorting.domain.ArticleTagRelation;
import com.yjj.wastesorting.domain.KnowledgeArticle;
import com.yjj.wastesorting.domain.Tags;
import com.yjj.wastesorting.mapper.ArticleTagRelationMapper;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.ArticleLikeService;
import com.yjj.wastesorting.service.ArticleTagRelationService;
import com.yjj.wastesorting.service.KnowledgeArticleService;
import com.yjj.wastesorting.mapper.KnowledgeArticleMapper;
import com.yjj.wastesorting.service.TagService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
* @author 26455
* @description 针对表【knowledge_article(科普文章表)】的数据库操作Service实现
* @createDate 2026-03-24 18:51:03
*/
@Service
public class KnowledgeArticleServiceImpl extends ServiceImpl<KnowledgeArticleMapper, KnowledgeArticle>
    implements KnowledgeArticleService{
    @Autowired
    private KnowledgeArticleMapper knowledgeArticleMapper;
    @Autowired
    private ArticleTagRelationService articleTagRelationService;
    @Autowired
    private TagService tagsService;
    @Autowired
    private ArticleTagRelationMapper articleTagRelationMapper;
    @Autowired
    private ArticleLikeService articleLikeService;
    @Override
    @Transactional
    public void saveOrupdate(PaperVo paperVo) {
        if (paperVo.getId() != null) {
            // 更新文章
            LambdaQueryWrapper<KnowledgeArticle> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(KnowledgeArticle::getId, paperVo.getId());
            KnowledgeArticle knowledgeArticle = knowledgeArticleMapper.selectOne(queryWrapper);

            knowledgeArticle.setTitle(paperVo.getTitle());
            knowledgeArticle.setContent(paperVo.getContent());
            knowledgeArticle.setCoverImage(paperVo.getCoverImage());
            knowledgeArticle.setAuthorName(paperVo.getAuthorName());

            // 删除旧的标签关联
            LambdaQueryWrapper<ArticleTagRelation> deleteWrapper = new LambdaQueryWrapper<>();
            deleteWrapper.eq(ArticleTagRelation::getArticleId, paperVo.getId());
            articleTagRelationMapper.delete(deleteWrapper);

            // 保存新的标签关联
            List<Long> tagIds = paperVo.getTags();
            if (!CollectionUtils.isEmpty(tagIds)) {
                for (Long tagId : tagIds) {
                    ArticleTagRelation articleTagRelation = new ArticleTagRelation();
                    articleTagRelation.setArticleId(knowledgeArticle.getId());
                    articleTagRelation.setTagId(tagId);
                    articleTagRelationMapper.insert(articleTagRelation);
                }
            }

            knowledgeArticleMapper.update(knowledgeArticle, queryWrapper);
        } else {
            // 新增文章
            KnowledgeArticle knowledgeArticle = new KnowledgeArticle();
            knowledgeArticle.setTitle(paperVo.getTitle());
            knowledgeArticle.setContent(paperVo.getContent());
            knowledgeArticle.setCoverImage(paperVo.getCoverImage());
            knowledgeArticle.setAuthorName(paperVo.getAuthorName());
            knowledgeArticleMapper.insert(knowledgeArticle);

            // 保存标签关联
            List<Long> tagIds = paperVo.getTags();
            if (!CollectionUtils.isEmpty(tagIds)) {
                for (Long tagId : tagIds) {
                    ArticleTagRelation articleTagRelation = new ArticleTagRelation();
                    articleTagRelation.setArticleId(knowledgeArticle.getId());
                    articleTagRelation.setTagId(tagId);
                    articleTagRelationMapper.insert(articleTagRelation);
                }
            }
        }
    }

    @Override
    public PaperReturnVo paperGetById(Long id) {
        List<Tags> tags = articleTagRelationMapper.getTagsByArticleId(id);
        KnowledgeArticle knowledgeArticle = knowledgeArticleMapper.selectById(id);
        PaperReturnVo paperReturnVo = new PaperReturnVo();
        BeanUtils.copyProperties(knowledgeArticle,paperReturnVo);
        paperReturnVo.setTags(tags);
        return paperReturnVo;
    }

    @Override
    public IPage<pageVo> pageQuery(Page<pageVo> page, String search) {
        return knowledgeArticleMapper.pageQuery(page,search);
    }

    @Override
    public void removeKonwledgeById(Long id) {
        LambdaQueryWrapper<ArticleTagRelation> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ArticleTagRelation::getArticleId, id);
        articleTagRelationMapper.delete(queryWrapper);
        knowledgeArticleMapper.deleteById(id);
    }

    @Override
    public IPage<UserPaperListVo> pagePaper(Page<UserPaperListVo> page, String keyword) {
        return knowledgeArticleMapper.pagePaper(page, keyword);
    }

    @Override
    public UserReadVo readPaperGetById(Long id) {
        KnowledgeArticle knowledgeArticle = knowledgeArticleMapper.selectById(id);
        if(knowledgeArticle==null)
        {
            return null;
        }
        UserReadVo userReadVo = new UserReadVo();
        userReadVo.setId(knowledgeArticle.getId());
        userReadVo.setTitle(knowledgeArticle.getTitle());
        userReadVo.setContent(knowledgeArticle.getContent());
        userReadVo.setCoverImage(knowledgeArticle.getCoverImage());
        userReadVo.setAuthorName(knowledgeArticle.getAuthorName());
        userReadVo.setViewCount(knowledgeArticle.getViewCount());
        userReadVo.setLikeCount(knowledgeArticle.getLikeCount());
        userReadVo.setCreateTime(knowledgeArticle.getCreateTime());
        knowledgeArticle.setViewCount(knowledgeArticle.getViewCount()+1);
        knowledgeArticleMapper.updateById(knowledgeArticle);
        return userReadVo;
    }

    @Override
    public void likePaper(Long id) {
        LoginUser loginUser = LoginUserHolder.getLoginUser();

        if (loginUser == null) {
            throw new RuntimeException("用户未登录");
        }

        Long userId = loginUser.getUserId();

        // ✅ 检查文章是否存在
        KnowledgeArticle article = knowledgeArticleMapper.selectById(id);
        if (article == null) {
            throw new RuntimeException("文章不存在");

        }

        // ✅ 检查用户是否已经点过赞
        LambdaQueryWrapper<ArticleLike> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ArticleLike::getArticleId, id);
        queryWrapper.eq(ArticleLike::getUserId, userId);
        ArticleLike existingLike = articleLikeService.getOne(queryWrapper);

        if (existingLike != null) {
            // ❌ 已经点过赞，取消点赞（二次点击取消）
            articleLikeService.removeById(existingLike.getId());

            // 减少文章点赞数
            LambdaUpdateWrapper<KnowledgeArticle> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(KnowledgeArticle::getId, id);
            updateWrapper.gt(KnowledgeArticle::getLikeCount, 0); // 防止负数
            updateWrapper.setSql("like_count = like_count - 1");
            knowledgeArticleMapper.update(null, updateWrapper);
        } else {
            // ✅ 第一次点赞，创建点赞记录
            ArticleLike articleLike = new ArticleLike();
            articleLike.setArticleId(id);
            articleLike.setUserId(userId);
            articleLikeService.save(articleLike);
            // 增加文章点赞数
            LambdaUpdateWrapper<KnowledgeArticle> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(KnowledgeArticle::getId, id);
            updateWrapper.setSql("like_count = like_count + 1");
            knowledgeArticleMapper.update(null, updateWrapper);
        }
    }

    @Override
    public IPage<UserPaperListVo> pageLikePaper(Page<UserPaperListVo> page, Long userId) {
        return knowledgeArticleMapper.pageLikePaper(page, userId);
    }

}




