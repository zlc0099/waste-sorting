package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.PrizeVo;
import com.yjj.wastesorting.Vo.UserListVo;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.domain.Prize;
import com.yjj.wastesorting.domain.PrizeExchange;
import com.yjj.wastesorting.domain.User;
import com.yjj.wastesorting.service.PrizeExchangeService;
import com.yjj.wastesorting.service.PrizeService;
import com.yjj.wastesorting.mapper.PrizeMapper;
import com.yjj.wastesorting.service.UserService;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
* @author 26455
* @description 针对表【prize(奖品表)】的数据库操作Service实现
* @createDate 2026-03-25 11:52:09
*/
@Service
public class PrizeServiceImpl extends ServiceImpl<PrizeMapper, Prize>
    implements PrizeService{
    @Autowired
    private PrizeMapper prizeMapper;
    @Autowired
    private PrizeExchangeService prizeExchangeService;
    @Autowired
    private UserService userService;

    @Override
    public void PrizeSaveOrUpdate(PrizeVo prizeVo) {
        if (prizeVo == null) {
            throw new RuntimeException("奖品数据不能为空");
        }

        if (prizeVo.getId() != null) {
            // 更新奖品
            LambdaQueryWrapper<Prize> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(Prize::getId, prizeVo.getId());
            Prize prize = this.getOne(queryWrapper);

            if (prize == null) {
                throw new RuntimeException("奖品不存在");
            }

            // 手动设置属性
            prize.setName(prizeVo.getName());
            prize.setImageUrl(prizeVo.getImageUrl());
            prize.setType(prizeVo.getType());
            prize.setPointsRequired(prizeVo.getPointsRequired());
            prize.setStock(prizeVo.getStock());
            prize.setTotalStock(prizeVo.getTotalStock());
            this.update(prize, queryWrapper);
        } else {

            if (prizeVo.getName() == null || prizeVo.getName().trim().isEmpty()) {
                throw new RuntimeException("奖品名称不能为空");
            }

            Prize prize = new Prize();
            // 手动设置属性（
            prize.setName(prizeVo.getName());
            prize.setImageUrl(prizeVo.getImageUrl());
            prize.setType(prizeVo.getType());
            prize.setPointsRequired(prizeVo.getPointsRequired());
            prize.setStock(prizeVo.getStock());
            prize.setTotalStock(prizeVo.getTotalStock());
            this.save(prize);
        }
    }

    @Override
    public IPage<Prize> pageQuery(Page<Prize> page, String prizeName) {
        return prizeMapper.pageQuery(page, prizeName);
    }

    @Override
    public IPage<UserListVo> pagePrizeQuery(Page<UserListVo> page, Integer type) {
        return prizeMapper.pagePrizeQuery(page, type);
    }

    @Override
    public void exchange(Long id) {
        Prize prize = this.getById(id);
        if (prize == null) {
            throw new RuntimeException("奖品不存在");
        }
        if (prize.getStock() <= 0) {
            throw new RuntimeException("奖品已售罄");
        }
        if(prize.getStatus()==0)
        {
            throw new RuntimeException("奖品已下架");
        }
        LoginUser loginUser = LoginUserHolder.getLoginUser();
        User user =  userService.getById(loginUser.getUserId());
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }
        if (user.getPoints() < prize.getPointsRequired()) {
            throw new RuntimeException("积分不足");
        }

        userService.updateById(user);
        PrizeExchange prizeExchange = new PrizeExchange();
        //用户是否已经兑换过该物品
        if(prizeMapper.getbyUserAndPrize(loginUser.getUserId(),id))
        {
            throw new RuntimeException("用户已经兑换过该物品");
        }
        user.setPoints(user.getPoints() - prize.getPointsRequired());
        userService.updateById(user);
        prizeExchange.setPrizeId(id);
        prizeExchange.setUserId(loginUser.getUserId());
        prizeExchange.setUsername(loginUser.getUsername());
        prizeExchange.setPointsUsed(prize.getPointsRequired());
        prizeExchange.setUsername(user.getUsername());
        prizeExchange.setStatus(0);
        prizeExchange.setCreateTime(new Date(System.currentTimeMillis()));
        prizeExchangeService.save(prizeExchange);
        prize.setStock(prize.getStock() - 1);
        this.updateById(prize);
    }
}




