package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.Register;
import com.yjj.wastesorting.Vo.UserInfoVo;
import com.yjj.wastesorting.Vo.UserLoginVo;
import com.yjj.wastesorting.Vo.UserVo;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.domain.User;
import com.yjj.wastesorting.domain.UserCheckIn;
import com.yjj.wastesorting.mapper.UserCheckInMapper;
import com.yjj.wastesorting.service.UserCheckInService;
import com.yjj.wastesorting.service.UserService;
import com.yjj.wastesorting.mapper.UserMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

/**
* @author 26455
* @description 针对表【user(用户表)】的数据库操作Service实现
* @createDate 2026-03-24 15:52:01
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
    implements UserService{
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private UserCheckInService userCheckInService;
    @Autowired
    private UserCheckInMapper userCheckInMapper;
    @Override
    public void saveOrupdate(UserVo userVo) {
        if(userVo.getId()!=null)
        {
            LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(User::getId,userVo.getId());
            User user = userMapper.selectOne(queryWrapper);
            user.setUsername(userVo.getUsername());
            user.setNickname(userVo.getNickname());
            user.setPassword(userVo.getPassword());
            user.setAvatar(userVo.getAvatar());
            userMapper.update(user,queryWrapper);
        }
        else
        {
            User user = new User();
            user.setNickname(userVo.getNickname());
            user.setUsername(userVo.getUsername());
            user.setPassword(userVo.getPassword());
            user.setAvatar(userVo.getAvatar());
            userMapper.insert(user);
        }
    }

    @Override
    public void updateStatus(Long id, Integer status) {
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getId,id);
        User user = userMapper.selectOne(queryWrapper);
        user.setStatus(status);
        userMapper.update(user,queryWrapper);
    }

    @Override
    public IPage<User> pageQuery(Page<User> page, String  username) {
        return userMapper.pageQuery(page,username);
    }

    @Override
    public void userRegitst(Register register) {
        if(register.getUsername()==null)
        {
            throw new RuntimeException("用户名不能为空");
        }
        if(register.getPassword()==null)
        {
            throw new RuntimeException("密码不能为空");
        }
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername,register.getUsername());
        if(userMapper.selectOne(queryWrapper)!=null)
        {
            throw new RuntimeException("用户已存在");
        }
        User user = new User();
        user.setUsername(register.getUsername());
        user.setPassword(register.getPassword());
        user.setNickname(register.getNickname());
        UserCheckIn userCheckIn = new UserCheckIn();
        userMapper.insert(user);
        User user1 = userMapper.selectOne(queryWrapper);
        userCheckIn.setUserId(user1.getId());
        userCheckIn.setCheckInDate(java.sql.Date.valueOf(LocalDate.now()));
        userCheckIn.setCheckIn(0);
        userCheckInService.save(userCheckIn);
    }

    @Override
    public UserVo userLogin(UserLoginVo userLoginVo) {
        if(userLoginVo.getUsername()==null) {
            throw new RuntimeException("用户名不能为空");
        }
        if(userLoginVo.getPassword()==null) {
            throw new RuntimeException("密码不能为空");
        }

        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUsername, userLoginVo.getUsername());
        User user = userMapper.selectOne(queryWrapper);

        if(user == null) {
            throw new RuntimeException("用户不存在");
        }
        if(!user.getPassword().equals(userLoginVo.getPassword())) {
            throw new RuntimeException("密码错误");
        }
        if(user.getStatus() == 0) {
            throw new RuntimeException("用户被禁用");
        }
        userMapper.updateById(user);
        UserVo userVo = new UserVo();
        BeanUtils.copyProperties(user, userVo);
        updateCheck(user.getId());
        return userVo;
    }

    @Override
    public UserInfoVo getUserInfo(Long id) {
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getId,id);
        User user = userMapper.selectOne(queryWrapper);
        UserInfoVo userInfoVo = new UserInfoVo();
        userInfoVo.setNickname(user.getNickname());
        userInfoVo.setAvatar(user.getAvatar());
        return userInfoVo;
    }
    public void updateCheck(Long id) {
        java.sql.Date today = java.sql.Date.valueOf(java.time.LocalDate.now());
        java.sql.Date yesterday = java.sql.Date.valueOf(java.time.LocalDate.now().minusDays(1));

        LambdaQueryWrapper<UserCheckIn> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(UserCheckIn::getUserId,id);
        queryWrapper.lt(UserCheckIn::getCheckInDate, today);
        UserCheckIn userCheckIn = userCheckInMapper.selectOne(queryWrapper);

        if (userCheckIn == null) {
            System.out.println("=== ✅ 今日已更新 ===");
            return;
        } else {
            if (userCheckIn.getCheckInDate().before(yesterday)) {
                System.out.println("=== ✅ 今日已更新 ===");
                return;
            }
            userCheckIn.setCheckInDate(today);
            userCheckIn.setCheckIn(0);
            userCheckInMapper.updateById(userCheckIn);
        }
    }
}




