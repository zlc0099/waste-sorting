package com.yjj.wastesorting.service;

import com.yjj.wastesorting.domain.ArticleLike;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【article_like(文章点赞表)】的数据库操作Service
* @createDate 2026-03-26 14:51:40
*/
public interface ArticleLikeService extends IService<ArticleLike> {

}
