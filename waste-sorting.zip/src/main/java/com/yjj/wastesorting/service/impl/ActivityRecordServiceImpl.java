package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.ActivityRecordVo;
import com.yjj.wastesorting.domain.ActivityRecord;
import com.yjj.wastesorting.service.ActivityRecordService;
import com.yjj.wastesorting.mapper.ActivityRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 26455
* @description 针对表【activity_record(活动参与记录表)】的数据库操作Service实现
* @createDate 2026-03-25 15:43:28
*/
@Service
public class ActivityRecordServiceImpl extends ServiceImpl<ActivityRecordMapper, ActivityRecord>
    implements ActivityRecordService{
    @Autowired
    private ActivityRecordMapper activityRecordMapper;

    @Override
    public IPage<ActivityRecordVo> recondPage(Page<ActivityRecordVo> page) {
        return activityRecordMapper.recondPage(page);
    }

    @Override
    public boolean isUserJoinActivity(Long id, Long userId) {
        LambdaQueryWrapper<ActivityRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(ActivityRecord::getActivityId,id)
                .eq(ActivityRecord::getUserId, userId);
        Long count = this.count(queryWrapper);
        return count != null && count > 0;
    }
}






