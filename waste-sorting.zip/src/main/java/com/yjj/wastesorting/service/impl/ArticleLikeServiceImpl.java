package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.domain.ArticleLike;
import com.yjj.wastesorting.service.ArticleLikeService;
import com.yjj.wastesorting.mapper.ArticleLikeMapper;
import org.springframework.stereotype.Service;

/**
* @author 26455
* @description 针对表【article_like(文章点赞表)】的数据库操作Service实现
* @createDate 2026-03-26 14:51:40
*/
@Service
public class ArticleLikeServiceImpl extends ServiceImpl<ArticleLikeMapper, ArticleLike>
    implements ArticleLikeService{

}




