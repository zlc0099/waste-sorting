package com.yjj.wastesorting.service;

import com.yjj.wastesorting.domain.Tags;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【tag(标签表)】的数据库操作Service
* @createDate 2026-03-24 19:09:37
*/
public interface TagService extends IService<Tags> {

    void add(String tagName);
}
