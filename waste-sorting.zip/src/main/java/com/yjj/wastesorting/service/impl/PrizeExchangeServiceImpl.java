package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.PrizeExchangeVo;
import com.yjj.wastesorting.domain.PrizeExchange;
import com.yjj.wastesorting.service.PrizeExchangeService;
import com.yjj.wastesorting.mapper.PrizeExchangeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 26455
* @description 针对表【prize_exchange(奖品兑换记录表)】的数据库操作Service实现
* @createDate 2026-03-25 11:52:09
*/
@Service
public class PrizeExchangeServiceImpl extends ServiceImpl<PrizeExchangeMapper, PrizeExchange>
    implements PrizeExchangeService{
    @Autowired
    private PrizeExchangeMapper prizeExchangeMapper;

    @Override
    public IPage<PrizeExchangeVo> pageQuery(Page<PrizeExchangeVo> page, String userName) {
        return prizeExchangeMapper.pageQuery(page, userName);
    }
}




