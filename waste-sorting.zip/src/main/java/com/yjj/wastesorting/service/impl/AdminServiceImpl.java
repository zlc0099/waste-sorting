package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.AddSystemUserVo;
import com.yjj.wastesorting.Vo.LoginVo;
import com.yjj.wastesorting.domain.Admin;
import com.yjj.wastesorting.service.AdminService;
import com.yjj.wastesorting.mapper.AdminMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 26455
* @description 针对表【admin(管理员表)】的数据库操作Service实现
* @createDate 2026-03-24 14:10:33
*/
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin>
    implements AdminService{
    @Autowired
    private AdminMapper adminMapper;
    @Override
    public void login(LoginVo admin) {
        if(admin.getUsername()==null||admin.getPassword()==null)
        {
            throw new RuntimeException("用户名或密码不能为空");
        }
        LambdaQueryWrapper<Admin> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Admin::getUsername,admin.getUsername());
        Admin admin1 = adminMapper.selectOne(queryWrapper);
        if(admin1==null)
        {
            throw new RuntimeException("用户不存在");
        }
        if(!admin1.getPassword().equals(admin.getPassword()))
        {
            throw new RuntimeException("密码错误");
        }
    }

    @Override
    public void saveOrUpdate(AddSystemUserVo addSystemUserVo) {
        if(addSystemUserVo.getId()!=null)
        {
            LambdaQueryWrapper<Admin> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(Admin::getId,addSystemUserVo.getId());
            Admin admin = adminMapper.selectOne(queryWrapper);
            admin.setUsername(addSystemUserVo.getUsername());
            admin.setPassword(addSystemUserVo.getPassword());
            admin.setAvatar(addSystemUserVo.getUrl());
            adminMapper.update(admin,queryWrapper);
        }
        else
        {
            Admin admin = new Admin();
            admin.setUsername(addSystemUserVo.getUsername());
            admin.setPassword(addSystemUserVo.getPassword());
            admin.setAvatar(addSystemUserVo.getUrl());
            adminMapper.insert(admin);
        }
    }

    @Override
    public IPage<Admin> pageQuery(Page<Admin> page) {
        return adminMapper.pageQuery(page);
    }
}




