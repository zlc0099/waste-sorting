package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.ActivityRecordVo;
import com.yjj.wastesorting.domain.ActivityRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【activity_record(活动参与记录表)】的数据库操作Service
* @createDate 2026-03-25 15:43:28
*/
public interface ActivityRecordService extends IService<ActivityRecord> {

    IPage<ActivityRecordVo> recondPage(Page<ActivityRecordVo> page);


    boolean isUserJoinActivity(Long id, Long userId);
}
