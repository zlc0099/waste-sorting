package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.ActivityVo;
import com.yjj.wastesorting.Vo.UserActivityKeyVo;
import com.yjj.wastesorting.Vo.UserActivityVo;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.domain.ActivityRecord;
import com.yjj.wastesorting.domain.EnvironmentalActivity;
import com.yjj.wastesorting.domain.User;
import com.yjj.wastesorting.service.ActivityRecordService;
import com.yjj.wastesorting.service.EnvironmentalActivityService;
import com.yjj.wastesorting.mapper.EnvironmentalActivityMapper;
import com.yjj.wastesorting.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 26455
* @description 针对表【environmental_activity(环保活动表)】的数据库操作Service实现
* @createDate 2026-03-25 15:43:35
*/
@Service
public class EnvironmentalActivityServiceImpl extends ServiceImpl<EnvironmentalActivityMapper, EnvironmentalActivity>
    implements EnvironmentalActivityService{
    @Autowired
    private EnvironmentalActivityMapper environmentalActivityMapper;
    @Autowired
    private ActivityRecordService activityRecordService;
    @Autowired
    private UserService userService;

    @Override
    public void activitySaveOrUpdate(ActivityVo activityVo) {
        if (activityVo == null) {
            throw new RuntimeException("活动数据不能为空");
        }

        if (activityVo.getId() != null) {
            // 更新活动
            LambdaQueryWrapper<EnvironmentalActivity> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(EnvironmentalActivity::getId, activityVo.getId());
            EnvironmentalActivity activity = this.getOne(queryWrapper);
            if (activity == null) {
                throw new RuntimeException("活动不存在");
            }

            activity.setTitle(activityVo.getTitle());
            activity.setDescription(activityVo.getDescription());
            activity.setCoverImage(activityVo.getCoverUrl());
            activity.setOrganizer(activityVo.getOrganizer());
            activity.setContactPhone(activityVo.getContactPhone());
            activity.setLocation(activityVo.getLocation());
            activity.setMaxParticipants(activityVo.getMaxParticipants());
            activity.setCurrentParticipants(0);
            activity.setRewardPoints(activityVo.getRewardPoints());
            activity.setStatus(activityVo.getStatus());

            this.update(activity, queryWrapper);
        } else {
            // 新增活动
            if (activityVo.getTitle() == null || activityVo.getTitle().trim().isEmpty()) {
                throw new RuntimeException("活动主题不能为空");
            }
            EnvironmentalActivity activity = new EnvironmentalActivity();
            // 手动设置属性
            activity.setTitle(activityVo.getTitle());
            activity.setDescription(activityVo.getDescription());
            activity.setCoverImage(activityVo.getCoverUrl());
            activity.setOrganizer(activityVo.getOrganizer());
            activity.setContactPhone(activityVo.getContactPhone());
            activity.setLocation(activityVo.getLocation());
            activity.setMaxParticipants(activityVo.getMaxParticipants());
            activity.setCurrentParticipants(activityVo.getCurrentParticipants() != null ? activityVo.getCurrentParticipants() : 0);
            activity.setRewardPoints(activityVo.getRewardPoints());
            activity.setStatus(activityVo.getStatus() != null ? activityVo.getStatus() : 0);

            this.save(activity);
        }
    }

    @Override
    public IPage<UserActivityVo> getActivity(IPage<UserActivityVo> page, String keyword) {
        return environmentalActivityMapper.getActivity(page, keyword);
    }

    @Override
    public UserActivityKeyVo getKeyById(Long id) {
        EnvironmentalActivity activity = this.getById(id);
        if(activity==null)
        {
            return null;
        }
        UserActivityKeyVo activityKeyVo = new UserActivityKeyVo();
        activityKeyVo.setTitle(activity.getTitle());
        activityKeyVo.setDescription(activity.getDescription());
        activityKeyVo.setCoverImage(activity.getCoverImage());
        activityKeyVo.setOrganizer(activity.getOrganizer());
        activityKeyVo.setContactPhone(activity.getContactPhone());
        activityKeyVo.setLocation(activity.getLocation());
        activityKeyVo.setStatus(activity.getStatus());
        activityKeyVo.setMaxParticipants(activity.getMaxParticipants());
        activityKeyVo.setCurrentParticipants(activity.getCurrentParticipants());
        activityKeyVo.setRewardPoints(activity.getRewardPoints());
        return activityKeyVo;
    }

    @Override
    public void saveJoinUser(Long id) {
        EnvironmentalActivity activity = this.getById(id);
        if(activity==null)
        {
            throw new RuntimeException("活动不存在");
        }
        if(activity.getStatus()!=0)
        {
            throw new RuntimeException("活动已结束");
        }
        if(activity.getCurrentParticipants()>=activity.getMaxParticipants())
        {
            throw new RuntimeException("活动已满");
        }
        LoginUser loginUser = LoginUserHolder.getLoginUser();
        User user = userService.getById(loginUser.getUserId());
        if(user==null)
        {
            throw new RuntimeException("用户不存在");
        }
        if(loginUser==null)
        {
            throw new RuntimeException("用户未登录");
        }
        if(activityRecordService.isUserJoinActivity(id,loginUser.getUserId()))
        {
            throw new RuntimeException("用户已报名");
        }
        ActivityRecord activityRecord = new ActivityRecord();
        activityRecord.setActivityId(id);
        activityRecord.setUserId(loginUser.getUserId());
        activityRecord.setUsername(user.getUsername());
        activityRecord.setStatus(0);
        activityRecord.setRewardPoints(activity.getRewardPoints());
        activityRecordService.save(activityRecord);
        activity.setCurrentParticipants(activity.getCurrentParticipants()+1);
        this.updateById(activity);
    }
}





