package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.Register;
import com.yjj.wastesorting.Vo.UserInfoVo;
import com.yjj.wastesorting.Vo.UserLoginVo;
import com.yjj.wastesorting.Vo.UserVo;
import com.yjj.wastesorting.domain.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【user(用户表)】的数据库操作Service
* @createDate 2026-03-24 15:52:01
*/
public interface UserService extends IService<User> {

    void saveOrupdate(UserVo userVo);

    void updateStatus(Long id, Integer status);

    IPage<User> pageQuery(Page<User> page,String  username);


    void userRegitst(Register register);

    UserVo userLogin(UserLoginVo userLoginVo);

    UserInfoVo getUserInfo(Long id);
}
