package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.AddSystemUserVo;
import com.yjj.wastesorting.Vo.LoginVo;
import com.yjj.wastesorting.domain.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【admin(管理员表)】的数据库操作Service
* @createDate 2026-03-24 14:10:33
*/
public interface AdminService extends IService<Admin> {

    void login(LoginVo admin);

    void saveOrUpdate(AddSystemUserVo addSystemUserVo);

    IPage<Admin> pageQuery(Page<Admin> page);
}
