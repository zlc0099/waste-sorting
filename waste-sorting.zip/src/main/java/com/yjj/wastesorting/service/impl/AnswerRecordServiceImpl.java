package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.UserAnswerStatVo;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.domain.AnswerRecord;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.AnswerRecordService;
import com.yjj.wastesorting.mapper.AnswerRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalDate;

/**
* @author 26455
* @description 针对表【answer_record(答题记录表)】的数据库操作Service实现
* @createDate 2026-03-25 18:47:00
*/
@Service
public class AnswerRecordServiceImpl extends ServiceImpl<AnswerRecordMapper, AnswerRecord>
    implements AnswerRecordService{
    @Autowired
    private AnswerRecordMapper answerRecordMapper;
    @Override
    public IPage<UserAnswerStatVo> userStatPageQuery(Page<UserAnswerStatVo> page) {
        return answerRecordMapper.userStatPageQuery(page);
    }
    @Override
    public Result<Integer> checkTodayAnswerLimit() {
        LoginUser loginUser = LoginUserHolder.getLoginUser();

        if (loginUser == null) {
            throw new RuntimeException("请先登录");
        }

        Long userId = loginUser.getUserId();
        LocalDate today = LocalDate.now();
        Date todayStart = java.sql.Date.valueOf(today);
        Date todayEnd = java.sql.Date.valueOf(today.plusDays(1));

        LambdaQueryWrapper<AnswerRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AnswerRecord::getUserId, userId);
        queryWrapper.ge(AnswerRecord::getAnswerTime, todayStart);
        queryWrapper.lt(AnswerRecord::getAnswerTime, todayEnd);
        queryWrapper.eq(AnswerRecord::getIsDeleted, 0);

        Long todayCount = this.count(queryWrapper);
        int dailyLimit = 5;
        int remainingCount = dailyLimit - todayCount.intValue();

        if (remainingCount < 0) {
            remainingCount = 0;
        }

        System.out.println("=== 用户 " + userId + " 今日已答：" + todayCount + " 题，还可答：" + remainingCount + " 题 ===");

        return Result.ok(remainingCount);
    }

    @Override
    public Page<AnswerRecord> pageQuery(Integer pageNum, Integer pageSize) {
        LoginUser loginUser = LoginUserHolder.getLoginUser();

        if (loginUser == null) {
            return new Page<>(pageNum, pageSize);
        }

        Long userId = loginUser.getUserId();

        Page<AnswerRecord> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<AnswerRecord> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AnswerRecord::getUserId, userId);
        queryWrapper.orderByDesc(AnswerRecord::getAnswerTime);

        return this.page(page, queryWrapper);
    }
}




