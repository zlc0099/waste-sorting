package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.PrizeVo;
import com.yjj.wastesorting.Vo.UserListVo;
import com.yjj.wastesorting.domain.Prize;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【prize(奖品表)】的数据库操作Service
* @createDate 2026-03-25 11:52:09
*/
public interface PrizeService extends IService<Prize> {

    void PrizeSaveOrUpdate(PrizeVo prizeVo);

    IPage<Prize> pageQuery(Page<Prize> page, String prizeName);

    IPage<UserListVo> pagePrizeQuery(Page<UserListVo> page, Integer type);

    void exchange(Long id);
}
