package com.yjj.wastesorting.service;

import com.yjj.wastesorting.domain.UserCheckIn;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【user_check_in(用户签到表)】的数据库操作Service
* @createDate 2026-03-26 09:39:59
*/
public interface UserCheckInService extends IService<UserCheckIn> {

    void checkIn();


}
