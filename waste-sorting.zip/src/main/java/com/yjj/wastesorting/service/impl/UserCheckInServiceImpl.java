package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.domain.User;
import com.yjj.wastesorting.domain.UserCheckIn;
import com.yjj.wastesorting.mapper.UserMapper;
import com.yjj.wastesorting.service.UserCheckInService;
import com.yjj.wastesorting.mapper.UserCheckInMapper;
import com.yjj.wastesorting.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;

/**
* @author 26455
* @description 针对表【user_check_in(用户签到表)】的数据库操作Service实现
* @createDate 2026-03-26 09:39:59
*/
@Service
public class UserCheckInServiceImpl extends ServiceImpl<UserCheckInMapper, UserCheckIn>
    implements UserCheckInService{
    @Lazy
    @Autowired
    private UserCheckInMapper userCheckInMapper;
    @Autowired
    private UserMapper userMapper;

    @Override
    public void checkIn() {
        LoginUser loginUser= LoginUserHolder.getLoginUser();
        LambdaQueryWrapper<UserCheckIn> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.eq(UserCheckIn::getUserId,loginUser.getUserId());
        UserCheckIn userCheckIn=userCheckInMapper.selectOne(queryWrapper);
        if(userCheckIn.getCheckIn()==1)
        {
            throw new RuntimeException("该用户已签到");
        }
        else
        {
            userCheckIn.setCheckIn(1);
            userCheckInMapper.updateById(userCheckIn);
            User user=userMapper.selectById(loginUser.getUserId());
            user.setPoints(user.getPoints()+userCheckIn.getPointsEarned());
            userMapper.updateById(user);
        }
    }

}




