package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.AnswerQuestionVo;
import com.yjj.wastesorting.Vo.AnswerResultVo;
import com.yjj.wastesorting.Vo.questionVo;
import com.yjj.wastesorting.domain.Question;
import com.baomidou.mybatisplus.extension.service.IService;
import com.yjj.wastesorting.result.Result;

/**
* @author 26455
* @description 针对表【question(垃圾分类题目表)】的数据库操作Service
* @createDate 2026-03-25 18:46:52
*/
public interface QuestionService extends IService<Question> {

    void questionSaveOrUpdate(questionVo questionVo);
    Result<AnswerResultVo> answerQuestion(AnswerQuestionVo answerQuestionVo);

    /**
     * 随机获取 N 道题目
     */
    Page<Question> getRandomQuestions(Integer count);

}
