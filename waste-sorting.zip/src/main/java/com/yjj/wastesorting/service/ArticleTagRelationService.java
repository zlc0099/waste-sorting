package com.yjj.wastesorting.service;

import com.yjj.wastesorting.domain.ArticleTagRelation;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【article_tag_relation(文章标签关联表)】的数据库操作Service
* @createDate 2026-03-24 19:09:44
*/
public interface ArticleTagRelationService extends IService<ArticleTagRelation> {

}
