package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.*;
import com.yjj.wastesorting.domain.KnowledgeArticle;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【knowledge_article(科普文章表)】的数据库操作Service
* @createDate 2026-03-24 18:51:03
*/
public interface KnowledgeArticleService extends IService<KnowledgeArticle> {

    void saveOrupdate(PaperVo paperVo);

    PaperReturnVo paperGetById(Long id);

    IPage<pageVo> pageQuery(Page<pageVo> page, String search);

    void removeKonwledgeById(Long id);

    IPage<UserPaperListVo> pagePaper(Page<UserPaperListVo> page, String keyword);

    UserReadVo readPaperGetById(Long id);

    void likePaper(Long id);

    IPage<UserPaperListVo> pageLikePaper(Page<UserPaperListVo> page, Long userId);
}
