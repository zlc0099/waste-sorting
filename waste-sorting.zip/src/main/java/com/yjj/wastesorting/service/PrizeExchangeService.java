package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.PrizeExchangeVo;
import com.yjj.wastesorting.domain.PrizeExchange;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【prize_exchange(奖品兑换记录表)】的数据库操作Service
* @createDate 2026-03-25 11:52:09
*/
public interface PrizeExchangeService extends IService<PrizeExchange> {

    IPage<PrizeExchangeVo> pageQuery(Page<PrizeExchangeVo> page, String userName);
}
