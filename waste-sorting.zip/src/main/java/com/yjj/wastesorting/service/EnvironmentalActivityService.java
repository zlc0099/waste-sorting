package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.yjj.wastesorting.Vo.ActivityVo;
import com.yjj.wastesorting.Vo.UserActivityKeyVo;
import com.yjj.wastesorting.Vo.UserActivityVo;
import com.yjj.wastesorting.domain.EnvironmentalActivity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 26455
* @description 针对表【environmental_activity(环保活动表)】的数据库操作Service
* @createDate 2026-03-25 15:43:35
*/
public interface EnvironmentalActivityService extends IService<EnvironmentalActivity> {

    void activitySaveOrUpdate(ActivityVo activityVo);

    IPage<UserActivityVo> getActivity(IPage<UserActivityVo> page, String keyword);

    UserActivityKeyVo getKeyById(Long id);

    void saveJoinUser(Long id);
}
