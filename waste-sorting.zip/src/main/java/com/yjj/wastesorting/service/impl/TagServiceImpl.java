package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.domain.Tags;
import com.yjj.wastesorting.service.TagService;
import com.yjj.wastesorting.mapper.TagMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 26455
* @description 针对表【tag(标签表)】的数据库操作Service实现
* @createDate 2026-03-24 19:09:37
*/
@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tags>
    implements TagService{
    @Autowired
    private TagMapper tagMapper;

    @Override
    public void add(String tagName) {
        Tags tags = new Tags();
        tags.setName(tagName);
        tagMapper.insert(tags);
    }
}




