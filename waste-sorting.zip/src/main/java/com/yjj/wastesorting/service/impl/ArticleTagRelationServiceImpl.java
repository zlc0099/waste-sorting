package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.domain.ArticleTagRelation;
import com.yjj.wastesorting.service.ArticleTagRelationService;
import com.yjj.wastesorting.mapper.ArticleTagRelationMapper;
import org.springframework.stereotype.Service;

/**
* @author 26455
* @description 针对表【article_tag_relation(文章标签关联表)】的数据库操作Service实现
* @createDate 2026-03-24 19:09:44
*/
@Service
public class ArticleTagRelationServiceImpl extends ServiceImpl<ArticleTagRelationMapper, ArticleTagRelation>
    implements ArticleTagRelationService{

}




