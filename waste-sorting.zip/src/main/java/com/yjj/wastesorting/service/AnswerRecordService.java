package com.yjj.wastesorting.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserAnswerStatVo;
import com.yjj.wastesorting.domain.AnswerRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.yjj.wastesorting.result.Result;

/**
* @author 26455
* @description 针对表【answer_record(答题记录表)】的数据库操作Service
* @createDate 2026-03-25 18:47:00
*/
public interface AnswerRecordService extends IService<AnswerRecord> {

    IPage<UserAnswerStatVo> userStatPageQuery(Page<UserAnswerStatVo> page);



    /**
     * 检查今日答题限制
     */
    Result<Integer> checkTodayAnswerLimit();

    /**
     * 分页查询答题记录
     */
    Page<AnswerRecord> pageQuery(Integer pageNum, Integer pageSize);
}
