package com.yjj.wastesorting.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yjj.wastesorting.Vo.AnswerQuestionVo;
import com.yjj.wastesorting.Vo.AnswerResultVo;
import com.yjj.wastesorting.Vo.questionVo;
import com.yjj.wastesorting.config.login.LoginUser;
import com.yjj.wastesorting.config.login.LoginUserHolder;
import com.yjj.wastesorting.domain.AnswerRecord;
import com.yjj.wastesorting.domain.Question;
import com.yjj.wastesorting.domain.User;
import com.yjj.wastesorting.mapper.AnswerRecordMapper;
import com.yjj.wastesorting.mapper.UserMapper;
import com.yjj.wastesorting.result.Result;
import com.yjj.wastesorting.service.QuestionService;
import com.yjj.wastesorting.mapper.QuestionMapper;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.List;
import java.util.Random;

/**
* @author 26455
* @description 针对表【question(垃圾分类题目表)】的数据库操作Service实现
* @createDate 2026-03-25 18:46:52
*/
@Service
public class QuestionServiceImpl extends ServiceImpl<QuestionMapper, Question>
    implements QuestionService{

    @Autowired
    private QuestionMapper questionMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private AnswerRecordMapper answerRecordMapper;
    @Override
    public void questionSaveOrUpdate(questionVo questionVo) {
        if (questionVo == null) {
            throw new RuntimeException("题目数据不能为空");
        }

        if (questionVo.getId() != null) {
            // 更新题目
            LambdaQueryWrapper<Question> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(Question::getId, questionVo.getId());
            Question question = this.getOne(queryWrapper);

            if (question == null) {
                throw new RuntimeException("题目不存在");
            }

            // 手动设置属性
            question.setTitle(questionVo.getTitle());
            question.setOptionA(questionVo.getOptionA());
            question.setOptionB(questionVo.getOptionB());
            question.setOptionC(questionVo.getOptionC());
            question.setOptionD(questionVo.getOptionD());
            question.setAnswer(questionVo.getAnswer());
            question.setScore(questionVo.getScore());
            this.update(question, queryWrapper);
        } else {
            // 新增题目
            if (questionVo.getTitle() == null || questionVo.getTitle().trim().isEmpty()) {
                throw new RuntimeException("题目标题不能为空");
            }

            if (questionVo.getOptionA() == null || questionVo.getOptionA().trim().isEmpty()) {
                throw new RuntimeException("选项 A 不能为空");
            }

            if (questionVo.getOptionB() == null || questionVo.getOptionB().trim().isEmpty()) {
                throw new RuntimeException("选项 B 不能为空");
            }

            if (questionVo.getOptionC() == null || questionVo.getOptionC().trim().isEmpty()) {
                throw new RuntimeException("选项 C 不能为空");
            }

            if (questionVo.getOptionD() == null || questionVo.getOptionD().trim().isEmpty()) {
                throw new RuntimeException("选项 D 不能为空");
            }

            if (questionVo.getAnswer() == null || questionVo.getAnswer().trim().isEmpty()) {
                throw new RuntimeException("正确答案不能为空");
            }
            Question question = new Question();
            // 手动设置属性
            question.setTitle(questionVo.getTitle());
            question.setOptionA(questionVo.getOptionA());
            question.setOptionB(questionVo.getOptionB());
            question.setOptionC(questionVo.getOptionC());
            question.setOptionD(questionVo.getOptionD());
            question.setAnswer(questionVo.getAnswer());
            question.setScore(questionVo.getScore());
            question.setStatus(1); // 默认启用
            this.save(question);
        }
    }
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Result<AnswerResultVo> answerQuestion(AnswerQuestionVo answerQuestionVo) {
        LoginUser loginUser = LoginUserHolder.getLoginUser();
        if (loginUser == null) {
            throw new RuntimeException("用户未登录");
        }

        Long userId = loginUser.getUserId();
        Long questionId = answerQuestionVo.getQuestionId();
        String userAnswer = answerQuestionVo.getUserAnswer();

        if (userAnswer == null || !userAnswer.matches("^[ABCD]$")) {
            throw new RuntimeException("用户答案格式错误");
        }

        Question question = questionMapper.selectById(questionId);
        if (question == null) {
            throw new RuntimeException("题目不存在");
        }

        if (question.getStatus() != 1) {
            throw new RuntimeException("题目已禁用");
        }

        boolean isCorrect = question.getAnswer().equalsIgnoreCase(userAnswer.toUpperCase());
        int scoreEarned = isCorrect ? question.getScore() : 0;

        AnswerRecord answerRecord = new AnswerRecord();
        answerRecord.setUserId(userId);
        answerRecord.setQuestionId(questionId);
        answerRecord.setUserAnswer(userAnswer.toUpperCase());
        answerRecord.setIsCorrect(isCorrect ? 1 : 0);
        answerRecord.setScoreEarned(scoreEarned);
        answerRecord.setAnswerTime(new Date(System.currentTimeMillis()));
        answerRecord.setCreateTime(new Date(System.currentTimeMillis()));
        answerRecordMapper.insert(answerRecord);

        if (isCorrect && scoreEarned > 0) {
            User user = userMapper.selectById(userId);
            if (user != null) {
                user.setPoints(user.getPoints() + scoreEarned);
                userMapper.updateById(user);
            }
        }

        AnswerResultVo resultVo = new AnswerResultVo();
        resultVo.setQuestionId(questionId);
        resultVo.setUserAnswer(userAnswer.toUpperCase());
        resultVo.setCorrectAnswer(question.getAnswer());
        resultVo.setIsCorrect(isCorrect);
        resultVo.setScoreEarned(scoreEarned);
        resultVo.setAnswerTime(new Date(System.currentTimeMillis()));

        return Result.ok(resultVo);
    }

    @Override
    public Page<Question> getRandomQuestions(Integer count) {
        LambdaQueryWrapper<Question> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Question::getStatus, 1);
        Page<Question> page = new Page<>(1, count == null ? 10 : count);
        Page<Question> resultPage = questionMapper.selectPage(page, queryWrapper);

        List<Question> questions = resultPage.getRecords();
        Random random = new Random();
        for (int i = questions.size() - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            Question temp = questions.get(index);
            questions.set(index, questions.get(i));
            questions.set(i, temp);
        }

        return resultPage;
    }
}





