package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class AnswerQuestionVo {
    /**
     * 题目 ID
     */
    private Long questionId;
    
    /**
     * 用户答案（A/B/C/D）
     */
    private String userAnswer;
}