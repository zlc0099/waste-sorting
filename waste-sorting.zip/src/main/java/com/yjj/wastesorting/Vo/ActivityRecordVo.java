package com.yjj.wastesorting.Vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.sql.Date;

@Data
public class ActivityRecordVo {
    /**
     * 记录 ID
     */
    private Long id;

    /**
     * 活动名称
     */
    private String activityTitle;

    /**
     * 用户名
     */
    private String username;

    /**
     * 状态（0-已报名 1-已签到 2-已完成 3-已取消）
     */
    private Integer status;

    /**
     * 签到时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date checkInTime;

    /**
     * 获得积分
     */
    private Integer rewardPoints;
}
