package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class UserInfoVo {
    private String nickname;
    private String avatar;
}
