package com.yjj.wastesorting.Vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import java.util.Date;

@Data
public class PrizeExchangeVo {
    private Long id;
    private Long prizeId;
    private Long userId;
    private String username;
    private String prizeName; // 奖品名称（关联查询）
    private Integer status; // 兑换状态
    private Integer pointsUsed; // 使用积分
    private String remark; // 备注
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
}