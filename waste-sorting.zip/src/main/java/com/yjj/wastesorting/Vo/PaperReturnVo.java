package com.yjj.wastesorting.Vo;

import com.yjj.wastesorting.domain.KnowledgeArticle;
import com.yjj.wastesorting.domain.Tags;
import lombok.Data;

import java.util.List;
@Data
public class PaperReturnVo extends KnowledgeArticle{
    private List<Tags> tags;
}
