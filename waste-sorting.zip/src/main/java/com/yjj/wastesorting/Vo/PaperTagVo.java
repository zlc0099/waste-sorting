package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class PaperTagVo {
    private Integer tagId;
    private Integer articleId;
}
