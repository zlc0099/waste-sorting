package com.yjj.wastesorting.Vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

@Data
public class UserListVo {
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 奖品名称
     */
    private String name;

    /**
     * 奖品图片 URL
     */
    private String imageUrl;

    /**
     * 奖品类型（1-实物 2-虚拟 3-优惠券）
     */
    private Integer type;

    /**
     * 所需积分
     */
    private Integer pointsRequired;

}
