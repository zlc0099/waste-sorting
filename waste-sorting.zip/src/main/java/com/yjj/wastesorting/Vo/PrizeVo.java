package com.yjj.wastesorting.Vo;

import lombok.Data;

import java.net.Inet4Address;

@Data
public class PrizeVo {
    private Long id;
    private String name;
    private String imageUrl;
    private Integer type;
    private Integer pointsRequired;
    private Integer stock;
    private Integer totalStock;
}
