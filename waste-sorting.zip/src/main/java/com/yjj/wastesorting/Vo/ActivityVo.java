package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class ActivityVo {
    private Long id;
    private String title;
    private String description;
    private String coverUrl;
    private String organizer;
    private String contactPhone;
    private String location;
    private Integer maxParticipants;
    private Integer currentParticipants;
    private Integer rewardPoints;
    private Integer status;

}
