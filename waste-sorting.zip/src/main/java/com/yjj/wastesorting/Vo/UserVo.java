package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class UserVo {
    private Long id;
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码（加密）
     */
    private String password;
    /**
     * 昵称
     */
    private String nickname;

    /**
     * 头像 URL
     */
    private String avatar;
}
