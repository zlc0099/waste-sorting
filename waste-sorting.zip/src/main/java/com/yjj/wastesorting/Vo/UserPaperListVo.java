package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class UserPaperListVo {
    private Long id;

    /**
     * 文章标题
     */
    private String title;

    private String coverImage;


    /**
     * 作者名称
     */
    private String authorName;

    /**
     * 浏览次数
     */

    private Integer viewCount;

    /**
     * 点赞次数
     */

    private Integer likeCount;

}
