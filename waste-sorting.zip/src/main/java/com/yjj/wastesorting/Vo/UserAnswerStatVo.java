package com.yjj.wastesorting.Vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class UserAnswerStatVo {
    /**
     * 用户 ID
     */
    private Long userId;

    /**
     * 用户名
     */
    private String username;

    /**
     * 回答正确的题目数
     */
    private Integer correctCount;

    /**
     * 总答题数
     */
    private Integer totalCount;

    /**
     * 回答正确率（百分比，保留 2 位小数）
     */
    private BigDecimal accuracyRate;

    /**
     * 所得积分总和
     */
    private Integer totalScore;
}