package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class AddSystemUserVo {
        private Integer id;
        private String username;
        private String password;
        private String Url;
}
