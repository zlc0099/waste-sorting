package com.yjj.wastesorting.Vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;
@Data
public class UserPrizeRecondVo {
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 奖品 ID
     */
    private Long prizeId;

    /**
     * 用户 ID
     */
    private Long userId;

    /**
     * 用户名（冗余字段）
     */
    private String username;

    /**
     * 使用积分
     */
    private Integer pointsUsed;
    /**
     * 备注
     */
    private String remark;

    /**
     * 兑换时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

}
