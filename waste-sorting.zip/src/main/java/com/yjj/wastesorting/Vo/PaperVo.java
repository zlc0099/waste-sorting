package com.yjj.wastesorting.Vo;

import com.yjj.wastesorting.domain.KnowledgeArticle;
import com.yjj.wastesorting.domain.Tags;
import lombok.Data;

import java.util.List;

@Data
public class PaperVo{
    private Long id;

    /**
     * 文章标题
     */
    private String title;

    /**
     * 文章内容
     */
    private String content;

    /**
     * 封面图片 URL
     */
    private String coverImage;


    /**
     * 作者名称
     */
    private String authorName;
    private List<Long> tags;
}
