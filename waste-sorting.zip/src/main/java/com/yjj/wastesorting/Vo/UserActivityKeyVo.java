package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class UserActivityKeyVo {
    private String title;
    private String description;
    private String coverImage;
    private String organizer;
    private String contactPhone;
    private String location;
    private Integer status;
    private Integer maxParticipants;
    private Integer currentParticipants;
    private Integer rewardPoints;
}
