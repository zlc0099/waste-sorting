package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class UserLoginVo {
    private String username;
    private String password;
}
