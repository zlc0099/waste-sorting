package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class Register {
    private String username;
    private String password;
    private String nickname;
}
