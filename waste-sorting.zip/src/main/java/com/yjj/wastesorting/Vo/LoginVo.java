package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class LoginVo {
    private String username;
    private String password;
}
