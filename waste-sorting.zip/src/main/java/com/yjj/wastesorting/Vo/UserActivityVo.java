package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class UserActivityVo {
    private Long id;
    private String title;
    private String coverImage;
}
