package com.yjj.wastesorting.Vo;

import lombok.Data;

@Data
public class questionVo {
    private Long id;

    /**
     * 题目标题
     */
    private String title;

    /**
     * 选项 A
     */
    private String optionA;

    /**
     * 选项 B
     */
    private String optionB;

    /**
     * 选项 C
     */
    private String optionC;

    /**
     * 选项 D
     */
    private String optionD;

    /**
     * 正确答案（A/B/C/D）
     */
    private String answer;

    /**
     * 分值（答对获得的积分）
     */
    private Integer score;
}
