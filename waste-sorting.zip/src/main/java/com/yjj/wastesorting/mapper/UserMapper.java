package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.domain.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author 26455
* @description 针对表【user(用户表)】的数据库操作Mapper
* @createDate 2026-03-24 15:52:01
* @Entity com.yjj.wastesorting.domain.User
*/
public interface UserMapper extends BaseMapper<User> {

    IPage<User> pageQuery(@Param("page") Page<User> page, @Param("username") String  username);
}




