package com.yjj.wastesorting.mapper;

import com.yjj.wastesorting.domain.ArticleLike;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 26455
* @description 针对表【article_like(文章点赞表)】的数据库操作Mapper
* @createDate 2026-03-26 14:51:40
* @Entity com.yjj.wastesorting.domain.ArticleLike
*/
public interface ArticleLikeMapper extends BaseMapper<ArticleLike> {

}




