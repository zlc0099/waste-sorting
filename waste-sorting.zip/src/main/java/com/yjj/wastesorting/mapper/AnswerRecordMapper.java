package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserAnswerStatVo;
import com.yjj.wastesorting.domain.AnswerRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author 26455
* @description 针对表【answer_record(答题记录表)】的数据库操作Mapper
* @createDate 2026-03-25 18:47:00
* @Entity com.yjj.wastesorting.domain.AnswerRecord
*/
public interface AnswerRecordMapper extends BaseMapper<AnswerRecord> {

    IPage<UserAnswerStatVo> userStatPageQuery(Page<UserAnswerStatVo> page);
}




