package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.PrizeExchangeVo;
import com.yjj.wastesorting.domain.PrizeExchange;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author 26455
* @description 针对表【prize_exchange(奖品兑换记录表)】的数据库操作Mapper
* @createDate 2026-03-25 11:52:09
* @Entity com.yjj.wastesorting.domain.PrizeExchange
*/
public interface PrizeExchangeMapper extends BaseMapper<PrizeExchange> {

    IPage<PrizeExchangeVo> pageQuery(@Param("page")Page<PrizeExchangeVo> page, @Param("userName")String userName);
}




