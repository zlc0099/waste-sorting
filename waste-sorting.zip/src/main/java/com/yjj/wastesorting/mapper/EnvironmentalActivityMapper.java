package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.yjj.wastesorting.Vo.UserActivityVo;
import com.yjj.wastesorting.domain.EnvironmentalActivity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author 26455
* @description 针对表【environmental_activity(环保活动表)】的数据库操作Mapper
* @createDate 2026-03-25 15:43:35
* @Entity com.yjj.wastesorting.domain.EnvironmentalActivity
*/
public interface EnvironmentalActivityMapper extends BaseMapper<EnvironmentalActivity> {

    IPage<UserActivityVo> getActivity(@Param("page")IPage<UserActivityVo> page, @Param("keyword")String keyword);
}




