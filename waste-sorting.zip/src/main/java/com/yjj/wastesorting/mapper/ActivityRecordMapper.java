package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.ActivityRecordVo;
import com.yjj.wastesorting.domain.ActivityRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author 26455
* @description 针对表【activity_record(活动参与记录表)】的数据库操作Mapper
* @createDate 2026-03-25 15:43:28
* @Entity com.yjj.wastesorting.domain.ActivityRecord
*/
public interface ActivityRecordMapper extends BaseMapper<ActivityRecord> {

    IPage<ActivityRecordVo> recondPage( @Param("page")Page<ActivityRecordVo> page);

}




