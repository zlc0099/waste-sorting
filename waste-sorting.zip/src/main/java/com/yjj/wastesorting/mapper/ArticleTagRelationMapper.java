package com.yjj.wastesorting.mapper;

import com.yjj.wastesorting.domain.ArticleTagRelation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yjj.wastesorting.domain.Tags;

import java.util.List;

/**
* @author 26455
* @description 针对表【article_tag_relation(文章标签关联表)】的数据库操作Mapper
* @createDate 2026-03-24 19:09:44
* @Entity com.yjj.wastesorting.domain.ArticleTagRelation
*/
public interface ArticleTagRelationMapper extends BaseMapper<ArticleTagRelation> {

    List<Tags> getTagsByArticleId(Long id);
}




