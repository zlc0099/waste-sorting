package com.yjj.wastesorting.mapper;

import com.yjj.wastesorting.domain.UserCheckIn;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 26455
* @description 针对表【user_check_in(用户签到表)】的数据库操作Mapper
* @createDate 2026-03-26 09:39:59
* @Entity com.yjj.wastesorting.domain.UserCheckIn
*/
public interface UserCheckInMapper extends BaseMapper<UserCheckIn> {

}




