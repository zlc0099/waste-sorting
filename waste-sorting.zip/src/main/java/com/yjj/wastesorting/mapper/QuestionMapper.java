package com.yjj.wastesorting.mapper;

import com.yjj.wastesorting.domain.Question;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 26455
* @description 针对表【question(垃圾分类题目表)】的数据库操作Mapper
* @createDate 2026-03-25 18:46:52
* @Entity com.yjj.wastesorting.domain.Question
*/
public interface QuestionMapper extends BaseMapper<Question> {

}




