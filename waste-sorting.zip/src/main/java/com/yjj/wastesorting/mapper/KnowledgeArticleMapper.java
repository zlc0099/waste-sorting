package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserPaperListVo;
import com.yjj.wastesorting.Vo.pageVo;
import com.yjj.wastesorting.domain.KnowledgeArticle;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yjj.wastesorting.domain.User;
import org.apache.ibatis.annotations.Param;

/**
* @author 26455
* @description 针对表【knowledge_article(科普文章表)】的数据库操作Mapper
* @createDate 2026-03-24 18:51:03
* @Entity com.yjj.wastesorting.domain.KnowledgeArticle
*/
public interface KnowledgeArticleMapper extends BaseMapper<KnowledgeArticle> {

    IPage<pageVo> pageQuery(@Param("page") Page<pageVo> page, @Param("search") String search);

    IPage<UserPaperListVo> pagePaper(@Param("page")Page<UserPaperListVo> page, @Param("keyword")String keyword);

    IPage<UserPaperListVo> pageLikePaper(@Param("page")Page<UserPaperListVo> page,@Param("userId") Long userId);
}




