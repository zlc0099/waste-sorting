package com.yjj.wastesorting.mapper;

import com.yjj.wastesorting.domain.Tags;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 26455
* @description 针对表【tag(标签表)】的数据库操作Mapper
* @createDate 2026-03-24 19:09:37
* @Entity com.yjj.wastesorting.domain.Tag
*/
public interface TagMapper extends BaseMapper<Tags> {

}




