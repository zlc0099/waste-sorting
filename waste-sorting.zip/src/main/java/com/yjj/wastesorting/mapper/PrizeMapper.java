package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.Vo.UserListVo;
import com.yjj.wastesorting.domain.Prize;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author 26455
* @description 针对表【prize(奖品表)】的数据库操作Mapper
* @createDate 2026-03-25 11:52:09
* @Entity com.yjj.wastesorting.domain.Prize
*/
public interface PrizeMapper extends BaseMapper<Prize> {

    IPage<Prize> pageQuery(@Param("page")Page<Prize> page, @Param("prizeName")String prizeName);

    IPage<UserListVo> pagePrizeQuery(@Param("page")Page<UserListVo> page,  @Param("type")Integer type);

    boolean getbyUserAndPrize(@Param("userId")Long userId,@Param("prizeId") Long id);
}




