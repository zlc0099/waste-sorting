package com.yjj.wastesorting.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yjj.wastesorting.domain.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 26455
* @description 针对表【admin(管理员表)】的数据库操作Mapper
* @createDate 2026-03-24 14:10:33
* @Entity com.yjj.wastesorting.domain.Admin
*/
public interface AdminMapper extends BaseMapper<Admin> {

    IPage<Admin> pageQuery(Page<Admin> page);
}




