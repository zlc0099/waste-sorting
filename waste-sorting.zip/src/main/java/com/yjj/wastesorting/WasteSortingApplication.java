package com.yjj.wastesorting;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.yjj.wastesorting.mapper")
@EnableScheduling
public class WasteSortingApplication {

    public static void main(String[] args) {
        SpringApplication.run(WasteSortingApplication.class, args);
    }

}
